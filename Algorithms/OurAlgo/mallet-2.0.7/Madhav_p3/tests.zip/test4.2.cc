#include "vm_app.h"


int main()
{
	while(vm_extend(0));
}